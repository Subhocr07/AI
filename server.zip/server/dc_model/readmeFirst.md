Update the openapi key.

This contains the model, there is a requirement.txt file which is similar to the last. Here is the output the model has been giving so far: 
"
Your question: what is the meaning of life
Hare Krishna!The meaning of life is to reawaken our God consciousness and serve the Supreme Lord, as stated in Bhagavad-gita Chapter 9, Verse 34:

"Abandon all varieties of religion and just surrender unto Me. I shall deliver you from all sinful reactions. Do not fear."
Chapter: 9
Verse: 34
Shloka : मन्मना भव मद्भक्तो मद्याजी मां नमस्कुरु | मामेवैष्यसि युक्त्वैवमात्मानं मत्परायण: || 34||
Translation : Engage your mind always in thinking of Me, become My devotee, offer obeisances to Me and worship Me. Being completely absorbed in Me, surely you will come to Me.
"
Please note the model and the dataset has to be placed to the same directory in the code editior to sucessfully run, else the path of the dataset needs to be changed. 